# -*- coding: utf-8 -*-
# @Author: qingshuizhiren
# @Date:   2018-03-30 15:12:13
# @Last Modified by:   qingshuizhiren
# @Last Modified time: 2018-03-30 15:13:28
# @E-mail: qingshuizhiren@foxmail.com
#
import os
print(os.getcwd())
print(os.name)
